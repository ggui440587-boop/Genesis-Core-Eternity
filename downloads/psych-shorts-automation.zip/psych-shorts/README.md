# 心理學搞笑Shorts 自動生成專案

全自動：主題 → AI文案 → AI配音 → 免版權背景素材 → 合成影片
你只需要：**每天/每週去下載生成好的影片，檢查一下，手動上傳YouTube**

全部工具皆為免費方案，不需要付費訂閱。

---

## 一、申請兩把免費 API Key（約10分鐘）

### 1. Gemini API Key（用來生成文案，免費額度很足夠）
1. 前往 https://aistudio.google.com/apikey
2. 用 Google帳號登入 → 點「Create API Key」
3. 複製產生的 Key，等一下要用

### 2. Pexels API Key（用來抓免版權背景影片，完全免費）
1. 前往 https://www.pexels.com/api/
2. 註冊帳號 → 送出簡短申請表單（幾乎秒過）
3. 複製 API Key

配音的部分（edge-tts）**不需要申請任何Key**，直接免費使用。

---

## 二、把這份程式碼放上GitHub（讓它能雲端排程執行）

1. 到 https://github.com 註冊帳號（如果還沒有）
2. 新增一個 repository（建議設為 **Private**，避免API用量或內容外流）
3. 把這個資料夾的所有檔案上傳到你的 repository
   （可以直接在GitHub網頁上「Add file → Upload files」把整個資料夾拖上去，不需要懂git指令）

## 三、設定API Key（GitHub Secrets，安全存放，不會外洩）

1. 進入你的 repository → 上方選單 **Settings**
2. 左側選單找到 **Secrets and variables → Actions**
3. 點 **New repository secret**，新增兩筆：
   - Name: `GEMINI_API_KEY`　Value: 貼上你的Gemini Key
   - Name: `PEXELS_API_KEY`　Value: 貼上你的Pexels Key

## 四、啟用自動排程

`.github/workflows/generate.yml` 這個檔案已經設定好：
- **每天台灣時間早上9點自動執行一次**，產生一支新影片
- 你也可以隨時手動觸發：進入 repository → **Actions** 分頁 → 左側選「自動生成心理學Shorts」→ 右側 **Run workflow** 按鈕，立即跑一次測試

## 五、下載生成好的影片

1. 進入 repository → **Actions** 分頁
2. 點進剛剛跑完的那次執行紀錄（綠色勾勾代表成功）
3. 頁面最下方 **Artifacts** 區塊，會有 `shorts-video-xxx.zip` 可以下載
4. 解壓縮後就是 `.mp4` 影片檔，檢查沒問題後手動上傳YouTube Studio

---

## 想調整的地方

- **主題清單**：修改 `config.py` 裡的 `TOPICS` 清單，想寫什麼心理學主題自己加
- **配音音色**：修改 `config.py` 的 `TTS_VOICE`（執行 `edge-tts --list-voices` 可看全部可選音色）
- **執行頻率**：修改 `.github/workflows/generate.yml` 裡的 `cron` 時間設定
- **文案語氣/長度**：修改 `scripts/generate_script.py` 裡的 prompt 文字

## 本機測試（如果想在自己電腦先跑跑看）

```bash
pip install -r requirements.txt
# macOS需另外安裝 ffmpeg：brew install ffmpeg
# Windows需另外安裝 ffmpeg：https://ffmpeg.org/download.html

export GEMINI_API_KEY="你的key"
export PEXELS_API_KEY="你的key"
python main.py
```

---

## 重要提醒

1. **不要全自動上傳**：YouTube對「大量、公式化、無人工審核」的AI內容有規範，
   你保留「手動上傳」這一步，順便看過內容、微調標題，是對的做法。
2. **先跑幾支測試品質**：文案品質、配音自然度、背景素材是否貼合主題，
   建議先手動跑3-5支檢查，覺得OK再開排程長期跑。
3. **免費額度上限**：Gemini和Pexels免費額度都足夠一天一支影片的用量，
   但若想一天出多支，留意各自的免費額度限制（超過會需要付費）。
