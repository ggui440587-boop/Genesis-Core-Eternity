# 心理學搞笑Shorts主題清單
# 每次執行會從清單中挑一個「還沒做過」的主題（用 used_topics.txt 記錄）
TOPICS = [
    "拖延症",
    "選擇困難",
    "假裝很忙",
    "鏡子效應",
    "曼德拉效應",
    "鄧寧克魯格效應",
    "確認偏誤",
    "從眾心理",
    "沉沒成本",
    "自我實現預言",
    "習得性無助",
    "月暈效應",
    "峰終定律",
    "社會期許偏誤",
    "旁觀者效應",
]

# 影片參數
VIDEO_WIDTH = 1080
VIDEO_HEIGHT = 1920  # 直式 9:16
FONT_SIZE = 64
FONT_COLOR = "white"

# edge-tts 中文語音（可自行更換，執行 `edge-tts --list-voices` 查看全部）
TTS_VOICE = "zh-TW-HsiaoChenNeural"  # 台灣中文女聲，也可用 zh-TW-YunJheNeural（男聲）
