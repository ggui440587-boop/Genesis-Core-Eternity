"""
主流程：主題 → 文案(Gemini) → 配音(edge-tts) → 背景素材(Pexels) → 合成(ffmpeg)
輸出：output/影片_日期時間.mp4，供你手動檢查後上傳YouTube
"""
import os
import random
from datetime import datetime

from config import TOPICS
from scripts.generate_script import generate_script
from scripts.generate_audio import generate_audio_sync
from scripts.fetch_footage import fetch_footage_with_fallback
from scripts.assemble_video import assemble_video

USED_TOPICS_FILE = "used_topics.txt"


def pick_topic() -> str:
    used = set()
    if os.path.exists(USED_TOPICS_FILE):
        with open(USED_TOPICS_FILE, encoding="utf-8") as f:
            used = set(line.strip() for line in f)
    remaining = [t for t in TOPICS if t not in used]
    if not remaining:
        # 全部用完就重新循環
        remaining = TOPICS
        open(USED_TOPICS_FILE, "w").close()
    topic = random.choice(remaining)
    with open(USED_TOPICS_FILE, "a", encoding="utf-8") as f:
        f.write(topic + "\n")
    return topic


def main():
    os.makedirs("output", exist_ok=True)
    os.makedirs("footage", exist_ok=True)

    topic = pick_topic()
    print(f"本次主題：{topic}")

    print("步驟1/4：生成文案中...")
    script = generate_script(topic)
    narration = script["narration"]
    keywords = script["keywords_en"]
    print(f"文案：\n{narration}\n關鍵字：{keywords}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    audio_path = f"output/audio_{timestamp}.mp3"
    footage_path = f"footage/footage_{timestamp}.mp4"
    narration_path = f"output/narration_{timestamp}.txt"
    output_path = f"output/shorts_{topic}_{timestamp}.mp4"

    with open(narration_path, "w", encoding="utf-8") as f:
        f.write(narration)

    print("步驟2/4：生成配音中...")
    generate_audio_sync(narration, audio_path)

    print("步驟3/4：下載背景素材中...")
    ok = fetch_footage_with_fallback(keywords, footage_path)
    if not ok:
        raise RuntimeError("背景素材下載失敗，請檢查PEXELS_API_KEY是否有效")

    print("步驟4/4：合成影片中...")
    assemble_video(footage_path, audio_path, narration, output_path)

    print(f"\n✅ 完成！請至 {output_path} 檢查影片，確認無誤後手動上傳YouTube")
    print(f"標題可參考：「你也有『{topic}』這個心理學現象嗎？」")


if __name__ == "__main__":
    main()
