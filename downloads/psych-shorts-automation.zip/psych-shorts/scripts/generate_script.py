"""
步驟1：用 Google Gemini API（免費額度）生成搞笑心理學短影音文案
申請免費 API Key：https://aistudio.google.com/apikey
"""
import os
import requests
import json

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]  # 從環境變數讀取，不要寫死在程式裡
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"


def generate_script(topic: str) -> dict:
    """
    回傳格式：
    {
        "narration": "口白文字（給TTS念）",
        "keywords_en": ["englishkeyword1", "englishkeyword2"]  # 給Pexels搜尋背景素材用
    }
    """
    prompt = f"""請針對心理學現象「{topic}」，寫一支45秒左右的搞笑短影音口白文案。

要求：
1. 開場一句話要有反差感/懸念，抓住注意力
2. 中段用口語化中文簡短解釋這個心理學效應（不要照抄書本或維基百科的句子，要用自己的話講）
3. 結尾要有神反轉或自嘲吐槽，讓人會心一笑
4. 全部口白控制在120-160字之間（念起來大約45秒）
5. 不要有任何舞台指示、分鏡符號、表情符號，只要純粹念出來的口白文字

另外，請提供2-3個「英文」關鍵字，用來搜尋適合當背景畫面的免版權影片素材（例如：thinking, clock, mirror, crowd 等抽象、通用的畫面詞，不要用心理學專有名詞，因為素材庫搜不到）。

請用以下 JSON 格式回覆，不要有其他文字：
{{"narration": "口白文字...", "keywords_en": ["keyword1", "keyword2"]}}
"""

    response = requests.post(
        GEMINI_URL,
        headers={"Content-Type": "application/json"},
        json={
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.9,
                "responseMimeType": "application/json",
            },
        },
        timeout=60,
    )
    response.raise_for_status()
    data = response.json()
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    result = json.loads(text)
    return result


if __name__ == "__main__":
    import sys
    topic = sys.argv[1] if len(sys.argv) > 1 else "拖延症"
    result = generate_script(topic)
    print(json.dumps(result, ensure_ascii=False, indent=2))
