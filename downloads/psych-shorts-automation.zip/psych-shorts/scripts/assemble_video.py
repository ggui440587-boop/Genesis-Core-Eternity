"""
步驟4：用 ffmpeg 把「背景素材 + 配音 + 字幕」合成一支完整直式短影音
不使用AI生成畫面，用真實影片素材裁切置中，畫面穩定不會變形/抽搐
"""
import subprocess
import json
import re
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
from config import VIDEO_WIDTH, VIDEO_HEIGHT, FONT_SIZE, FONT_COLOR


def get_audio_duration(audio_path: str) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "json", audio_path],
        capture_output=True, text=True, check=True,
    )
    return float(json.loads(result.stdout)["format"]["duration"])


def split_sentences(text: str) -> list:
    """依標點切句，用來分配字幕時間軸"""
    parts = re.split(r"([。！？，,!?])", text)
    sentences = []
    buf = ""
    for p in parts:
        buf += p
        if p in "。！？!?":
            sentences.append(buf.strip())
            buf = ""
    if buf.strip():
        sentences.append(buf.strip())
    return [s for s in sentences if s]


def seconds_to_srt_time(sec: float) -> str:
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    ms = int((sec - int(sec)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def generate_srt(narration: str, total_duration: float, srt_path: str):
    """依每句字數比例分配時間，產生字幕檔（燒錄用）"""
    sentences = split_sentences(narration)
    total_chars = sum(len(s) for s in sentences) or 1
    t = 0.0
    lines = []
    for i, sentence in enumerate(sentences, start=1):
        dur = total_duration * (len(sentence) / total_chars)
        start, end = t, t + dur
        lines.append(f"{i}\n{seconds_to_srt_time(start)} --> {seconds_to_srt_time(end)}\n{sentence}\n")
        t = end
    with open(srt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def assemble_video(footage_path: str, audio_path: str, narration: str, output_path: str):
    duration = get_audio_duration(audio_path)

    srt_path = output_path.replace(".mp4", ".srt")
    generate_srt(narration, duration, srt_path)

    # 濾鏡：裁切置中成9:16、迴圈補足時長到配音長度、燒錄字幕
    vf = (
        f"scale={VIDEO_WIDTH}:{VIDEO_HEIGHT}:force_original_aspect_ratio=increase,"
        f"crop={VIDEO_WIDTH}:{VIDEO_HEIGHT},"
        f"subtitles={srt_path}:force_style="
        f"'FontSize={FONT_SIZE // 2},PrimaryColour=&H00FFFFFF,"
        f"OutlineColour=&H00000000,BorderStyle=1,Outline=3,Alignment=2,MarginV=120'"
    )

    cmd = [
        "ffmpeg", "-y",
        "-stream_loop", "-1", "-i", footage_path,  # 背景影片迴圈播放
        "-i", audio_path,
        "-vf", vf,
        "-map", "0:v:0", "-map", "1:a:0",
        "-t", str(duration),
        "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest",
        output_path,
    ]
    subprocess.run(cmd, check=True)
    print(f"影片合成完成：{output_path}")


if __name__ == "__main__":
    footage = sys.argv[1]
    audio = sys.argv[2]
    narration_file = sys.argv[3]  # 存口白文字的txt檔路徑
    output = sys.argv[4]
    with open(narration_file, encoding="utf-8") as f:
        narration = f.read()
    assemble_video(footage, audio, narration, output)
