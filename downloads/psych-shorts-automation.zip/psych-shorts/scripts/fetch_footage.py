"""
步驟3：用 Pexels API（免費）搜尋並下載直式背景影片素材
申請免費 API Key：https://www.pexels.com/api/
"""
import os
import requests

PEXELS_API_KEY = os.environ["PEXELS_API_KEY"]
PEXELS_URL = "https://api.pexels.com/videos/search"


def fetch_footage(keyword: str, output_path: str, min_duration: int = 8) -> bool:
    """搜尋關鍵字，下載一支直式（portrait）影片存到 output_path，成功回傳True"""
    response = requests.get(
        PEXELS_URL,
        headers={"Authorization": PEXELS_API_KEY},
        params={"query": keyword, "orientation": "portrait", "per_page": 5},
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()

    for video in data.get("videos", []):
        if video["duration"] < min_duration:
            continue
        # 選畫質適中的檔案（避免下載太大的4K檔）
        files = sorted(video["video_files"], key=lambda f: f.get("width", 0))
        for f in files:
            if f.get("width", 0) >= 720:
                video_url = f["link"]
                video_data = requests.get(video_url, timeout=60).content
                with open(output_path, "wb") as out:
                    out.write(video_data)
                return True
    return False


def fetch_footage_with_fallback(keywords: list, output_path: str) -> bool:
    """依序嘗試關鍵字清單，直到成功下載一支影片"""
    for kw in keywords:
        try:
            if fetch_footage(kw, output_path):
                print(f"成功下載素材，關鍵字：{kw}")
                return True
        except Exception as e:
            print(f"關鍵字「{kw}」下載失敗：{e}")
    # 最後保底：用最通用的抽象背景詞
    fallback_keywords = ["abstract background", "soft gradient", "clouds sky"]
    for kw in fallback_keywords:
        try:
            if fetch_footage(kw, output_path):
                print(f"使用保底素材，關鍵字：{kw}")
                return True
        except Exception:
            continue
    return False


if __name__ == "__main__":
    import sys
    kw = sys.argv[1] if len(sys.argv) > 1 else "thinking"
    out = sys.argv[2] if len(sys.argv) > 2 else "test_footage.mp4"
    ok = fetch_footage_with_fallback([kw], out)
    print("成功" if ok else "失敗")
