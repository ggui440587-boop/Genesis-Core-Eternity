"""
步驟2：用 edge-tts（微軟Edge內建語音，完全免費、不需API key）生成配音
"""
import asyncio
import edge_tts

import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
from config import TTS_VOICE


async def generate_audio(text: str, output_path: str):
    communicate = edge_tts.Communicate(text, TTS_VOICE, rate="+5%")
    await communicate.save(output_path)


def generate_audio_sync(text: str, output_path: str):
    asyncio.run(generate_audio(text, output_path))


if __name__ == "__main__":
    import sys
    text = sys.argv[1] if len(sys.argv) > 1 else "這是一段測試口白。"
    out = sys.argv[2] if len(sys.argv) > 2 else "test_audio.mp3"
    generate_audio_sync(text, out)
    print(f"已產生：{out}")
